# Create variables for an integer, a floating point number, a character string, 
# and a boolean value
a = 500
b = 100240.759834772
c = 'Hello, World!'
d = False

# verify variable types
print(type(a))
print(type(b))
print(type(c))
print(type(d))

# Use C-style printf formatting to construct a string with your variables; 
# limit the floating point number to 2 decimal places
print('%i, %.2f, %s, %s' % (a,b,c,d))

# Construct a string with your variables using the string format method; 
# represent the boolean value as 0 for False and 1 for True
s = '{0}: {1:d}\t{2}\t{3}\t{4}'.format(d, d, a, b, c)
print(s)

#C-style booleans
print('%s %s' % (True, False))
print('%i %i' % (True, False))
print()

# Construct a string using the python 3.6 (or later) formatted string
t = f'{a} {b:,.2f}\n{c[:5]}\n{d}'
print(t)