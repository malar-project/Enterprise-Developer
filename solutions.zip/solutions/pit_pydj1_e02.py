values = [ 3, 53, 19, -5, 60, 41, "test", 5, 22, 9, 22]
# Create a loop using a for or while
for i in values:
# Use one or more if-elif-else conditional statements within the loop
  if i == 9:
# Use a break statement
    break
  elif isinstance(i, str):
# Use a continue statement
    continue
  else:
    print(i)

# while loop example
total = 0
loop = 0
while total < 200:
  if isinstance(values[loop], str):
    loop += 1
    continue
  elif values[loop] > 0:
    total += values[loop]
  else:
    print(f'skipping {values[loop]}')

  if loop == len(values)-1:
    break
  loop += 1

print(f'sum: {total}, loop: {loop}')